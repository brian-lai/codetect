# LiteLLM HTTP Client Resilience

**Date:** 2026-03-14
**Branch:** `pret/litellm-resilience`
**Scope:** Single file change — `internal/embedding/litellm.go` + tests

## Objective

Fix repeated EOF errors when calling the LiteLLM embedding API during `codetect index`. The client currently uses Go's default HTTP transport (2 idle connections per host, no connection management) and has zero retry/backoff logic, causing transient connection drops to cascade into total embedding failure.

## Root Cause Analysis

Three issues confirmed in the code:

1. **No custom HTTP Transport** (`litellm.go:82-84`) — `&http.Client{Timeout: c.timeout}` uses Go defaults: `MaxIdleConnsPerHost=2`, short idle timeout. Stale TLS connections produce EOF on reuse.

2. **No batch-level retry** (`litellm.go:114-130`) — `Embed()` calls `embedBatch()` once, and on any error immediately fragments into N individual calls via `embedIndividualFallback()`. A single transient EOF triggers N+1 total requests.

3. **No backoff in individual fallback** (`litellm.go:192-219`) — `embedIndividualFallback()` loops with zero delay between requests. If the server is recovering from a hiccup, this hammers it immediately.

## Approach

All changes are scoped to `internal/embedding/litellm.go` and its test file.

### Step 1: Configure HTTP Transport

Replace the bare `&http.Client{Timeout: c.timeout}` with a custom transport:

```go
c.httpClient = &http.Client{
    Timeout: c.timeout,
    Transport: &http.Transport{
        MaxIdleConns:        100,
        MaxIdleConnsPerHost: 10,
        IdleConnTimeout:     90 * time.Second,
    },
}
```

This prevents stale-connection EOF by keeping a healthy pool and cycling idle connections before the server drops them.

**Tests:** Verify `NewLiteLLMClient` sets a non-nil Transport with expected pool settings.

### Step 2: Add retry with backoff to `embedBatch`

Extract a new `doRequest` helper that wraps `httpClient.Do` with up to 3 retries and exponential backoff (200ms, 400ms, 800ms) for retryable errors (EOF, connection reset, 429, 502, 503). Non-retryable errors (400, 401, 413) fail immediately.

```go
func (c *LiteLLMClient) doWithRetry(req *http.Request, body []byte) (*http.Response, error) {
    // up to 3 attempts with 200ms * 2^attempt backoff
    // only retry on: EOF, connection reset, 429, 502, 503
}
```

Integrate into `embedBatch` so the batch gets 3 attempts before falling through to individual fallback.

**Tests:**
- Mock server that fails 2x with EOF then succeeds → verify batch succeeds on 3rd attempt
- Mock server that returns 429 twice then 200 → verify retry works for rate limits
- Mock server that returns 400 → verify no retry (immediate failure)
- Mock server that always fails → verify fallback to individual still happens

### Step 3: Add backoff to `embedIndividualFallback`

Add a small delay between individual retry calls: `time.Sleep(100ms * (i+1))` capped at 2s. This prevents hammering the server when it's recovering.

**Tests:**
- Mock server that fails on batch, succeeds on individual → verify embeddings returned
- Verify context cancellation is respected during backoff (doesn't hang)

## Risks

- **Increased latency on transient failures** — Retries add up to ~1.4s before fallback. Acceptable since the alternative is total failure.
- **Ollama client has same pattern** — Same bare `http.Client` in `ollama.go:68`. Not in scope for this PR but noted for follow-up.

## Success Criteria

- [ ] `codetect index --force --clear-cache` completes without EOF cascade on a LiteLLM endpoint
- [ ] Transient EOF (1-2 failures) recovers transparently via batch retry
- [ ] Sustained server outage falls through to individual fallback with backoff
- [ ] All existing tests pass
- [ ] New tests cover retry, backoff, and non-retryable error paths

## Testing Strategy

All tests use `httptest.NewServer` to simulate failure modes:

1. **TestLiteLLMClient_Transport** — Verify custom transport is configured
2. **TestLiteLLMClient_RetryOnEOF** — Server drops connection 2x, succeeds 3rd → batch succeeds
3. **TestLiteLLMClient_RetryOn429** — Server returns 429 twice, then 200 → batch succeeds
4. **TestLiteLLMClient_NoRetryOn400** — Server returns 400 → immediate failure, no retry
5. **TestLiteLLMClient_FallbackAfterMaxRetries** — Server always EOFs → falls through to individual fallback
6. **TestLiteLLMClient_IndividualBackoff** — Batch fails, individuals succeed with delay
7. **TestLiteLLMClient_IndividualBackoffContextCancel** — Context cancelled during backoff → returns promptly
